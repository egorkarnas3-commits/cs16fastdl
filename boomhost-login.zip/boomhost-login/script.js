// ДЕМО-логика. На реальном сайте отправку кода и проверку делает сервер.
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
let pending = { mode: null, email: "", code: "" };
let timerId = null;

const $ = (sel, root = document) => root.querySelector(sel);

function showView(name) {
  document.querySelectorAll("[data-view]").forEach(v => {
    v.hidden = v.dataset.view !== name;
  });
  const first = $(`[data-view="${name}"] input`);
  if (first) first.focus();
}

function setError(view, msg) {
  const el = $("[data-error]", view);
  if (el) el.textContent = msg;
}

// ЗАГЛУШКА отправки письма. Здесь будет fetch() к серверу.
function sendCodeToEmail(email) {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  const code = String(100000 + (buf[0] % 900000));
  console.log(`[DEMO] Код для ${email}: ${code}`);
  return code;
}

function startCodeStep(mode, email) {
  pending = { mode, email, code: sendCodeToEmail(email) };
  $('[data-email]').textContent = email;
  clearOtp();
  showView("code");
  startResendTimer(60);
}

document.addEventListener("click", e => {
  const btn = e.target.closest("[data-go]");
  if (btn) {
    setError(document, "");
    showView(btn.dataset.go);
  }
});

$('[data-view="login"] form').addEventListener("submit", e => {
  e.preventDefault();
  const view = $('[data-view="login"]');
  const email = $("#login-email").value.trim();
  const pass = $("#login-pass").value;
  if (!EMAIL_RE.test(email)) return setError(view, "Введите корректный email");
  if (!pass) return setError(view, "Введите пароль");
  setError(view, "");
  startCodeStep("login", email);
});

$('[data-view="register"] form').addEventListener("submit", e => {
  e.preventDefault();
  const view = $('[data-view="register"]');
  const name = $("#reg-name").value.trim();
  const email = $("#reg-email").value.trim();
  const pass = $("#reg-pass").value;
  if (!name) return setError(view, "Введите имя пользователя");
  if (!EMAIL_RE.test(email)) return setError(view, "Введите корректный email");
  if (pass.length < 8) return setError(view, "Пароль должен быть не короче 8 символов");
  setError(view, "");
  startCodeStep("register", email);
});

$('[data-view="forgot"] form').addEventListener("submit", e => {
  e.preventDefault();
  const view = $('[data-view="forgot"]');
  const email = $("#forgot-email").value.trim();
  if (!EMAIL_RE.test(email)) return setError(view, "Введите корректный email");
  setError(view, "");
  startCodeStep("reset", email);
});

$('[data-view="newpass"] form').addEventListener("submit", e => {
  e.preventDefault();
  const view = $('[data-view="newpass"]');
  if ($("#new-pass").value.length < 8) return setError(view, "Пароль должен быть не короче 8 символов");
  setError(view, "");
  alert("Пароль изменён. Теперь можно войти.");
  showView("login");
});

// Поля кода
const otpInputs = [...document.querySelectorAll("[data-otp] input")];
const otpBox = $("[data-otp]");

function clearOtp() {
  otpInputs.forEach(i => { i.value = ""; i.classList.remove("invalid"); });
  setError($('[data-view="code"]'), "");
}

function getOtp() {
  return otpInputs.map(i => i.value).join("");
}

otpInputs.forEach((input, idx) => {
  input.addEventListener("input", () => {
    input.value = input.value.replace(/\D/g, "").slice(-1);
    if (input.value && idx < otpInputs.length - 1) otpInputs[idx + 1].focus();
    if (getOtp().length === 6) verifyCode();
  });

  input.addEventListener("keydown", e => {
    if (e.key === "Backspace" && !input.value && idx > 0) {
      otpInputs[idx - 1].focus();
      otpInputs[idx - 1].value = "";
    }
  });

  input.addEventListener("paste", e => {
    e.preventDefault();
    const digits = (e.clipboardData.getData("text") || "").replace(/\D/g, "").slice(0, 6);
    digits.split("").forEach((d, i) => { otpInputs[i].value = d; });
    otpInputs[Math.min(digits.length, 5)].focus();
    if (digits.length === 6) verifyCode();
  });
});

function verifyCode() {
  const view = $('[data-view="code"]');
  if (getOtp() === pending.code) {
    setError(view, "");
    if (pending.mode === "reset") {
      showView("newpass");
    } else {
      alert(pending.mode === "register"
        ? "Аккаунт создан! Добро пожаловать в BoomHost & BoomCorp."
        : "Вход выполнен!");
    }
  } else {
    setError(view, "Неверный код. Попробуйте ещё раз");
    otpBox.classList.remove("shake");
    void otpBox.offsetWidth;
    otpBox.classList.add("shake");
    otpInputs.forEach(i => i.classList.add("invalid"));
    otpInputs.forEach(i => i.value = "");
    otpInputs[0].focus();
  }
}

$("[data-verify]").addEventListener("click", () => {
  if (getOtp().length < 6) return setError($('[data-view="code"]'), "Введите все 6 цифр");
  verifyCode();
});

// Таймер повторной отправки
const resendBtn = $("[data-resend]");
const timerEl = $("[data-timer]");

function startResendTimer(seconds) {
  clearInterval(timerId);
  resendBtn.disabled = true;
  let left = seconds;
  timerEl.textContent = `(${left} с)`;
  timerId = setInterval(() => {
    left--;
    if (left <= 0) {
      clearInterval(timerId);
      resendBtn.disabled = false;
      timerEl.textContent = "";
    } else {
      timerEl.textContent = `(${left} с)`;
    }
  }, 1000);
}

resendBtn.addEventListener("click", () => {
  pending.code = sendCodeToEmail(pending.email);
  clearOtp();
  setError($('[data-view="code"]'), "Код отправлен повторно");
  startResendTimer(60);
});

showView("login");
